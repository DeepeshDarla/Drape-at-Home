# THE DRAPER — Brand System Package

This package contains the canonical brand references and documentation for THE DRAPER.

## Canonical assets

- `public/brand/character/the-draper-advisor-master-reference-v1.jpg`
- `public/brand/logo/the-draper-monogram-master.jpg`
- `public/brand/logo/the-draper-primary-logo-master.png`

## How to install into the website repository

Copy the `public/`, `docs/brand/` and `prompts/character/` folders into the root of the THE DRAPER website repository, preserving the folder structure.

Do not overwrite existing website assets without checking whether they are already approved/canonical.

## How to use the advisor with Nano Banana

1. Attach `the-draper-advisor-master-reference-v1.jpg` as the primary character reference.
2. Attach the official monogram master whenever the logo is visible.
3. Use the base character prompt in `prompts/character/the-draper-advisor-base-prompt.md`.
4. Add only the scene-specific instructions after the base character instructions.
5. Do not ask the image model to redesign the character or logo.
6. Save approved generated images with descriptive lowercase kebab-case filenames.

## Important

GitHub is the source of truth for the brand assets; it does not automatically make Nano Banana use the images. The reference images still need to be attached/provided to the image-generation workflow.
